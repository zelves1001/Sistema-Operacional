import threading

lock = threading.Lock()
lock.acquire()

lock.release()